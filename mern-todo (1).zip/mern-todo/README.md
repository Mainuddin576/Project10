# MERN Task Manager

A simple full-stack to-do app built with MongoDB, Express, React (Vite) and Node.js.

## Features

- Add, complete and delete tasks
- Data stored in MongoDB
- REST API with Express + Mongoose
- React frontend with Vite dev proxy (no CORS setup needed in dev)

## Project structure

```
mern-todo/
├── server/
│   ├── models/Task.js
│   ├── routes/tasks.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
└── client/
    ├── src/
    │   ├── App.jsx
    │   ├── App.css
    │   └── main.jsx
    ├── index.html
    ├── vite.config.js
    └── package.json
```

## Setup

Requirements: Node.js 18+ and MongoDB (local) or a MongoDB Atlas URI.

### 1. Backend

```bash
cd server
npm install
cp .env.example .env     # edit MONGO_URI if needed
npm run dev
```

Server runs on http://localhost:5000

### 2. Frontend

```bash
cd client
npm install
npm run dev
```

App runs on http://localhost:5173

## API

| Method | Endpoint           | Description                    |
|--------|--------------------|--------------------------------|
| GET    | /api/tasks         | List all tasks                 |
| POST   | /api/tasks         | Create task `{ "title": "..." }` |
| PUT    | /api/tasks/:id     | Update `title` and/or `completed` |
| DELETE | /api/tasks/:id     | Delete a task                  |
