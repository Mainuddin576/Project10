import { useEffect, useState } from "react";

const API = "/api/tasks";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function request(url, options) {
    const res = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Something went wrong");
    return data;
  }

  useEffect(() => {
    request(API)
      .then(setTasks)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  async function addTask(e) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const task = await request(API, {
        method: "POST",
        body: JSON.stringify({ title }),
      });
      setTasks((prev) => [task, ...prev]);
      setTitle("");
      setError("");
    } catch (e) {
      setError(e.message);
    }
  }

  async function toggleTask(task) {
    try {
      const updated = await request(`${API}/${task._id}`, {
        method: "PUT",
        body: JSON.stringify({ completed: !task.completed }),
      });
      setTasks((prev) => prev.map((t) => (t._id === updated._id ? updated : t)));
    } catch (e) {
      setError(e.message);
    }
  }

  async function deleteTask(id) {
    try {
      await request(`${API}/${id}`, { method: "DELETE" });
      setTasks((prev) => prev.filter((t) => t._id !== id));
    } catch (e) {
      setError(e.message);
    }
  }

  const remaining = tasks.filter((t) => !t.completed).length;

  return (
    <main className="container">
      <h1>Task Manager</h1>
      <p className="subtitle">
        {loading ? "Loading..." : `${remaining} of ${tasks.length} tasks remaining`}
      </p>

      <form onSubmit={addTask} className="form">
        <input
          type="text"
          placeholder="Add a new task..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={200}
        />
        <button type="submit">Add</button>
      </form>

      {error && <p className="error">{error}</p>}

      <ul className="list">
        {tasks.map((task) => (
          <li key={task._id} className={task.completed ? "done" : ""}>
            <label>
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTask(task)}
              />
              <span>{task.title}</span>
            </label>
            <button className="delete" onClick={() => deleteTask(task._id)}>
              Delete
            </button>
          </li>
        ))}
        {!loading && tasks.length === 0 && <li className="empty">No tasks yet. Add one above.</li>}
      </ul>
    </main>
  );
}
